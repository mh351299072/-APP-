//窗口自适应
$(function(){
	$(window).resize(initFont);
	function initFont() {
		var htmlWidth = $(window).width();
		if (htmlWidth >= 640) {
			$('html').css({
				'font-size' : 24 + 'px'

			})
		} else {
			$('html').css({
				'font-size' : 24 / 640 * htmlWidth + 'px'
			})
		}
	}initFont();
});
//日历

